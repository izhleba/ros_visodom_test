#ifndef LIBVISO_MONO_ODOMETR
#define LIBVISO_MONO_ODOMETR

#include "ros/ros.h"
#include "nav_msgs/Odometry.h"
#include "../libviso2/viso_mono.h"
#include <sensor_msgs/image_encodings.h>
#include <cv_bridge/cv_bridge.h>
#include <image_transport/camera_subscriber.h>
#include <image_transport/image_transport.h>
#include <image_geometry/pinhole_camera_model.h>
#include "odometer_base.h"

class LibvisoMonoOdometer : public OdometerBase {

public:

//    LibvisoMonoOdometer(const ros::NodeHandle &_nodeHandle, const std::string &imageTopic,
//                        const std::string &infoTopic) : OdometerBase(_nodeHandle, imageTopic, infoTopic);

    LibvisoMonoOdometer(const ros::NodeHandle &_nodeHandle, const std::string &imageTopic,
                        const std::string &infoTopic) : OdometerBase(_nodeHandle, imageTopic, infoTopic) {
        // Read local parameters
        ros::NodeHandle local_nh("~");
        loadParams(local_nh, visualOdometerParams);
    }

protected:

    boost::shared_ptr<VisualOdometryMono> visualOdometer;
    VisualOdometryMono::parameters visualOdometerParams;

    void imageAnInfoCallback(const sensor_msgs::ImageConstPtr &imageMsg, const sensor_msgs::CameraInfoConstPtr &infoMsg);

    void loadParams(const ros::NodeHandle &local_nh, Matcher::parameters &params) {
        local_nh.getParam("nms_n", params.nms_n);
        local_nh.getParam("nms_tau", params.nms_tau);
        local_nh.getParam("match_binsize", params.match_binsize);
        local_nh.getParam("match_radius", params.match_radius);
        local_nh.getParam("match_disp_tolerance", params.match_disp_tolerance);
        local_nh.getParam("outlier_disp_tolerance", params.outlier_disp_tolerance);
        local_nh.getParam("outlier_flow_tolerance", params.outlier_flow_tolerance);
        local_nh.getParam("multi_stage", params.multi_stage);
        local_nh.getParam("half_resolution", params.half_resolution);
        local_nh.getParam("refinement", params.refinement);
    }


    void loadParams(const ros::NodeHandle &local_nh, VisualOdometry::bucketing &bucketing) {
        local_nh.getParam("max_features", bucketing.max_features);
        local_nh.getParam("bucket_width", bucketing.bucket_width);
        local_nh.getParam("bucket_height", bucketing.bucket_height);
    }


    void loadCommonParams(const ros::NodeHandle &local_nh, VisualOdometry::parameters &params) {
        loadParams(local_nh, params.match);
        loadParams(local_nh, params.bucket);
    }


    void loadParams(const ros::NodeHandle &local_nh, VisualOdometryMono::parameters &params) {
        loadCommonParams(local_nh, params);
        if (!local_nh.getParam("camera_height", params.height)) {
            ROS_WARN("Parameter 'camera_height' is required but not set. Using default: %f", params.height);
        }
        if (!local_nh.getParam("camera_pitch", params.pitch)) {
            ROS_WARN("Paramter 'camera_pitch' is required but not set. Using default: %f", params.pitch);
        }
        local_nh.getParam("ransac_iters", params.ransac_iters);
        local_nh.getParam("inlier_threshold", params.inlier_threshold);
        local_nh.getParam("motion_threshold", params.motion_threshold);
    }
};

#endif //LIBVISO_MONO_ODOMETR