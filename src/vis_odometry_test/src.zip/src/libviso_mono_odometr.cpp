
#include "ros/ros.h"
#include "nav_msgs/Odometry.h"
#include "../libviso2/viso_mono.h"
#include <image_transport/camera_subscriber.h>
#include <image_transport/image_transport.h>
#include <image_geometry/pinhole_camera_model.h>
#include "odometer_base.h"
#include "libviso_mono_odometr.h"


//class LibvisoMonoOdometer : public OdometerBase {
//
//private:
//
//    boost::shared_ptr <VisualOdometryMono> visualOdometer;
//    VisualOdometryMono::parameters visualOdometerParams;
//
//
//public:

//    LibvisoMonoOdometer::LibvisoMonoOdometer(const ros::NodeHandle &_nodeHandle, const std::string &imageTopic,
//                        const std::string &infoTopic) : OdometerBase(_nodeHandle, imageTopic, infoTopic) {
//        // Read local parameters
//        ros::NodeHandle local_nh("~");
//        odometry_params::loadParams(local_nh, visualOdometerParams);
//    }
//
//protected:

    void LibvisoMonoOdometer::imageAnInfoCallback(
            const sensor_msgs::ImageConstPtr &imageMsg,
            const sensor_msgs::CameraInfoConstPtr &infoMsg) {
        ros::WallTime startTime = ros::WallTime::now();

        bool firstRun = false;
        // create odometer if not exists
        if (!visualOdometer) {
            firstRun = true;
            // read calibration info from camera info message
            // to fill remaining odometer parameters
            image_geometry::PinholeCameraModel model;
            model.fromCameraInfo(infoMsg);
            visualOdometerParams.calib.f = model.fx();
            visualOdometerParams.calib.cu = model.cx();
            visualOdometerParams.calib.cv = model.cy();
            visualOdometer.reset(new VisualOdometryMono(visualOdometerParams));
            if (imageMsg->header.frame_id != "") setSensorFrameId(imageMsg->header.frame_id);
            ROS_INFO_STREAM("Initialized libviso2 mono odometry "
                                    "with the following parameters:" << std::endl <<
                                                                     visualOdometerParams);
        }

        // convert image if necessary
        uint8_t *imageData;
        int step;
        cv_bridge::CvImageConstPtr cv_ptr;
        if (imageMsg->encoding == sensor_msgs::image_encodings::MONO8) {
            imageData = const_cast<uint8_t *>(&(imageMsg->data[0]));
            step = imageMsg->step;
        } else {
            cv_ptr = cv_bridge::toCvShare(imageMsg, sensor_msgs::image_encodings::MONO8);
            imageData = cv_ptr->image.data;
            step = cv_ptr->image.step[0];
        }

        // run the odometer
        int32_t dims[] = {imageMsg->width, imageMsg->height, step};
        // on first run, only feed the odometer with first image pair without
        // retrieving data
        if (firstRun) {
            visualOdometer->process(imageData, dims);
            tf::Transform deltaTransform;
            deltaTransform.setIdentity();
            integrateAndPublish(deltaTransform, imageMsg->header.stamp);
        } else {
            bool success = visualOdometer->process(imageData, dims);
            if (success) {
                Matrix camera_motion = Matrix::inv(visualOdometer->getMotion());
                ROS_DEBUG("Found %i matches with %i inliers.",
                          visualOdometer->getNumberOfMatches(),
                          visualOdometer->getNumberOfInliers());
                ROS_DEBUG_STREAM("libviso2 returned the following motion:\n" << camera_motion);

                tf::Matrix3x3 rotationMat(
                        camera_motion.val[0][0], camera_motion.val[0][1], camera_motion.val[0][2],
                        camera_motion.val[1][0], camera_motion.val[1][1], camera_motion.val[1][2],
                        camera_motion.val[2][0], camera_motion.val[2][1], camera_motion.val[2][2]);
                tf::Vector3 translationVec(camera_motion.val[0][3], camera_motion.val[1][3], camera_motion.val[2][3]);
                tf::Transform deltaTransform(rotationMat, translationVec);

                integrateAndPublish(deltaTransform, imageMsg->header.stamp);
            } else {
                ROS_DEBUG("Call to VisualOdometryMono::process() failed. Assuming motion too small.");
                tf::Transform deltaTransform;
                deltaTransform.setIdentity();
                integrateAndPublish(deltaTransform, imageMsg->header.stamp);
            }
        }
    }
//};
//
//
//int main(int argc, char **argv) {
//    ros::init(argc, argv, "mono_odometer");
//    if (ros::names::remap("image").find("rect") == std::string::npos) {
//        ROS_WARN("mono_odometer needs rectified input images. The used image "
//                         "topic is '%s'. Are you sure the images are rectified?",
//                 ros::names::remap("image").c_str());
//    }
//
//    std::string transport = argc > 1 ? argv[1] : "raw";
//    viso2_ros::MonoOdometer odometer(transport);
//
//    ros::spin();
//    return 0;
//}


