#include "ros/ros.h"
#include "nav_msgs/Odometry.h"
#include "../libviso2/viso_mono.h"
#include <image_transport/camera_subscriber.h>
#include <image_transport/image_transport.h>
#include <image_geometry/pinhole_camera_model.h>

#include <opencv2/highgui/highgui.hpp>
#include <cv_bridge/cv_bridge.h>

#include <tf/transform_listener.h>
#include <tf/transform_broadcaster.h>
#include "libviso_mono_odometr.h"


#include <camera_info_manager/camera_info_manager.h>

/**
 * This tutorial demonstrates simple receipt of position and speed of the Evarobot over the ROS system.
 */

/**
 * Callback function executes when new topic data comes.
 * Task of the callback function is to print data to screen.
 */
//boost::shared_ptr<VisualOdometryMono> visual_odometer_;
//VisualOdometryMono::parameters visual_odometer_params_;
//tf::Transform integrated_pose_;
//bool first_run = true;
//
//
//void integrateAndPublish(const tf::Transform& delta_transform, const ros::Time& timestamp) {
//    integrated_pose_ *= delta_transform;
//    nav_msgs::Odometry odometry_msg;
//    tf::poseTFToMsg(integrated_pose_, odometry_msg.pose.pose);
//    ROS_INFO("Pred position-> x: [%f], y: [%f], z: [%f]", odometry_msg.pose.pose.position.x,
//             odometry_msg.pose.pose.position.y,
//             odometry_msg.pose.pose.position.z);
//}
//
//void chatterCallback(const nav_msgs::Odometry::ConstPtr &msg) {
////    ROS_INFO_STREAM("Tick");
////    ROS_INFO("Seq: [%d]", msg->header.seq);
//    ROS_INFO("Real position-> x: [%f], y: [%f], z: [%f]", msg->pose.pose.position.x, msg->pose.pose.position.y,
//             msg->pose.pose.position.z);
////    ROS_INFO("Orientation-> x: [%f], y: [%f], z: [%f], w: [%f]", msg->pose.pose.orientation.x,
////             msg->pose.pose.orientation.y, msg->pose.pose.orientation.z, msg->pose.pose.orientation.w);
////    ROS_INFO("Vel-> Linear: [%f], Angular: [%f]", msg->twist.twist.linear.x, msg->twist.twist.angular.z);
//}
//
//void imageCallback(const sensor_msgs::ImageConstPtr &image_msg) {
////    ROS_INFO_STREAM("Image tick");
//    if (visual_odometer_) {
//        // convert image if necessary
//        uint8_t *image_data;
//        int step;
//        cv_bridge::CvImageConstPtr cv_ptr;
//        if (image_msg->encoding == sensor_msgs::image_encodings::MONO8) {
//            image_data = const_cast<uint8_t *>(&(image_msg->data[0]));
//            step = image_msg->step;
//        } else {
//            cv_ptr = cv_bridge::toCvShare(image_msg, sensor_msgs::image_encodings::MONO8);
//            image_data = cv_ptr->image.data;
//            step = cv_ptr->image.step[0];
//        }
//
//        // run the odometer
//        int32_t dims[] = {image_msg->width, image_msg->height, step};
//        // on first run, only feed the odometer with first image pair without
//        // retrieving data
//        if (first_run) {
//            first_run = false;
//            visual_odometer_->process(image_data, dims);
//        } else {
//            bool success = visual_odometer_->process(image_data, dims);
//            if (success) {
//                Matrix camera_motion = Matrix::inv(visual_odometer_->getMotion());
////                ROS_INFO("Found %i matches with %i inliers.",
////                          visual_odometer_->getNumberOfMatches(),
////                          visual_odometer_->getNumberOfInliers());
////                ROS_INFO_STREAM("libviso2 returned the following motion:\n" << camera_motion);
//
//                tf::Matrix3x3 rot_mat(
//                        camera_motion.val[0][0], camera_motion.val[0][1], camera_motion.val[0][2],
//                        camera_motion.val[1][0], camera_motion.val[1][1], camera_motion.val[1][2],
//                        camera_motion.val[2][0], camera_motion.val[2][1], camera_motion.val[2][2]);
//                tf::Vector3 t(camera_motion.val[0][3], camera_motion.val[1][3], camera_motion.val[2][3]);
//                tf::Transform delta_transform(rot_mat, t);
//
//                integrateAndPublish(delta_transform, image_msg->header.stamp);
//            } else {
////                ROS_INFO("Call to VisualOdometryMono::process() failed. Assuming motion too small.");
////                replace_ = true;
//                tf::Transform delta_transform;
//                delta_transform.setIdentity();
//                integrateAndPublish(delta_transform, image_msg->header.stamp);
//            }
//
//            // create and publish viso2 info msg
////            VisoInfo info_msg;
////            info_msg.header.stamp = image_msg->header.stamp;
////            info_msg.got_lost = !success;
////            info_msg.change_reference_frame = false;
////            info_msg.num_matches = visual_odometer_->getNumberOfMatches();
////            info_msg.num_inliers = visual_odometer_->getNumberOfInliers();
////            ros::WallDuration time_elapsed = ros::WallTime::now() - start_time;
////            info_msg.runtime = time_elapsed.toSec();
////            info_pub_.publish(info_msg);
//        }
//    }
////    try {
////        cv::imshow("view", cv_bridge::toCvShare(msg, "bgr8")->image);
////        cv::waitKey(30);
////    }
////    catch (cv_bridge::Exception &e) {
////        ROS_ERROR("Could not convert from '%s' to 'bgr8'.", msg->encoding.c_str());
////    }
//}
//
//void cameraInfoCallback(const sensor_msgs::CameraInfoConstPtr &info_msg) {
////    ROS_INFO_STREAM("Info tick");
//    if (!visual_odometer_) {
//        ROS_INFO_STREAM("Odometer initialization");
//        image_geometry::PinholeCameraModel model;
//        model.fromCameraInfo(info_msg);
//        visual_odometer_params_.calib.f = model.fx();
//        visual_odometer_params_.calib.cu = model.cx();
//        visual_odometer_params_.calib.cv = model.cy();
//        visual_odometer_.reset(new VisualOdometryMono(visual_odometer_params_));
//        ROS_INFO_STREAM("Initialized libviso2 mono odometry with the following parameters:" << visual_odometer_params_);
//    }
//}
//
//
//int main(int argc, char **argv) {
//    ros::init(argc, argv, "odom_listener");
//
//    ros::NodeHandle nodeHandle;
//
//    ROS_INFO_STREAM("It's alive!");
//
////    cv::namedWindow("view");
////    cv::startWindowThread();
//    integrated_pose_.setIdentity();
//    image_transport::ImageTransport it(nodeHandle);
//    image_transport::Subscriber imageSub = it.subscribe("/wide_stereo/left/image_rect_throttle", 1, imageCallback);
//
//
//    ros::Subscriber odomSub = nodeHandle.subscribe("/base_odometry/odom", 1000, &chatterCallback);
//
//    ros::Subscriber sub = nodeHandle.subscribe("/wide_stereo/left/camera_info_throttle", 1, cameraInfoCallback);
//
////    image_transport::ImageTransport it(nodeHandle);
////    image_transport::CameraSubscriber camSub = it.subscribeCamera("/wide_stereo/right/image_rect_throttle", 1,
////                                                                  &cameraCallback);
//    ros::spin();
////    cv::destroyWindow("view");
//    return 0;
//}

//void cameraInfoCallback(const sensor_msgs::CameraInfoConstPtr &info_msg) {
//    ROS_INFO_STREAM("Info tick");
//}

int main(int argc, char **argv) {
    ros::init(argc, argv, "odom_listener");
    ros::NodeHandle nodeHandle;
    ROS_INFO_STREAM("It's alive!");
    LibvisoMonoOdometer odometer(nodeHandle,"/wide_stereo/left/image_rect_throttle","/wide_stereo/left/camera_info_throttle");
//    nodeHandle.subscribe("/wide_stereo/left/camera_info_throttle",1,cameraInfoCallback);

//    ros::Subscriber sub = nodeHandle.subscribe("/wide_stereo/left/camera_info_throttle", 1, cameraInfoCallback);
    ros::spin();
    return 0;
}
